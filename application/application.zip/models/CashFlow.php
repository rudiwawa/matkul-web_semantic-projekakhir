<?php

class User extends CI_Model
{

    protected $users = 'pegawai';
    protected $date;
    
}
